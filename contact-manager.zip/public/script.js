const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const phoneInput = document.getElementById('phone');
const addButton = document.getElementById('add-button');
const clearButton = document.getElementById('clear-all');
const contactList = document.getElementById('contact-list');

window.onload = () => loadContacts();

async function loadContacts() {
    const res = await fetch('/api/contacts');
    const contacts = await res.json();
    contactList.innerHTML = '';
    contacts.forEach(renderContact);
}

function renderContact(contact) {
    const li = document.createElement('li');
    li.textContent = `${contact.name} - ${contact.email} - ${contact.phone}`;
    li.dataset.id = contact.id;
    const delBtn = document.createElement('button');
    delBtn.textContent = 'Delete';
    delBtn.onclick = async () => {
        await fetch(`/api/contacts/${contact.id}`, { method: 'DELETE' });
        li.remove();
    };
    li.appendChild(delBtn);
    contactList.appendChild(li);
}

addButton.onclick = async () => {
    const name = nameInput.value.trim();
    const email = emailInput.value.trim();
    const phone = phoneInput.value.trim();
    if (!name || !email || !phone) {
        alert('Please fill all fields');
        return;
    }
    const res = await fetch('/api/contacts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, phone })
    });
    const newContact = await res.json();
    renderContact(newContact);
    nameInput.value = '';
    emailInput.value = '';
    phoneInput.value = '';
};

clearButton.onclick = async () => {
    if (confirm("Are you sure you want to clear all contacts?")) {
        await fetch('/api/contacts', { method: 'DELETE' });
        contactList.innerHTML = '';
    }
};