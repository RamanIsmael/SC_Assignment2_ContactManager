const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

let contacts = [];

// GET all contacts
app.get('/api/contacts', (req, res) => {
    res.json(contacts);
});

// POST new contact
app.post('/api/contacts', (req, res) => {
    const { name, email, phone } = req.body;
    const newContact = {
        id: Date.now(),
        name,
        email,
        phone
    };
    contacts.push(newContact);
    res.status(201).json(newContact);
});

// DELETE single contact
app.delete('/api/contacts/:id', (req, res) => {
    const id = parseInt(req.params.id);
    contacts = contacts.filter(contact => contact.id !== id);
    res.status(204).send();
});

// DELETE all contacts
app.delete('/api/contacts', (req, res) => {
    contacts = [];
    res.status(204).send();
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});